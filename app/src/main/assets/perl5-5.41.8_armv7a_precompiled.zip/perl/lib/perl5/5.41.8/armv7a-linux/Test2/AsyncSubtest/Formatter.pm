package Test2::AsyncSubtest::Formatter;
use strict;
use warnings;

our $VERSION = '1.302207';

die "Should not load this anymore";

1;
